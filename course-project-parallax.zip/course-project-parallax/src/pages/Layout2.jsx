import { Outlet, Link } from "react-router-dom";

const Layout2 = () => {
	return (
		<>
			<Outlet />
		</>
	);
};
export default Layout2;
